from django.db import models
from uuid import uuid4

class User(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    username = models.CharField(max_length=64, blank=False, verbose_name='Имя пользователя')
    login = models.CharField(max_length=32, verbose_name='Логин', unique=True, blank=False)
    password = models.CharField(max_length=64, verbose_name='Пароль', blank=False)
    is_admin = models.BooleanField(verbose_name='Админ', default=False)


    def __str__(self):
        return self.username

