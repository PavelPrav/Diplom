from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponseNotAllowed, HttpResponse
from django.urls import reverse_lazy
from .models import User
from tests.models import Test
from .utils import compress

def reg_auth_page(request):
    if request.session.get('login'):
        return HttpResponseRedirect(redirect_to=reverse_lazy('home'))
    
    return render(request, 'registration.html')

def authorization(request):
    if request.method == 'POST':
        login = request.POST.get('login')
        password = request.POST.get('password')

        if not login or not password:
            return HttpResponse('login or password not found')
        
        password = compress(password)
        try:
            user = User.objects.get(login=login, password=password)
            request.session['login'] = user.login
            request.session['username'] = user.username
            request.session['user_id'] = str(user.id)

            return HttpResponseRedirect(reverse_lazy('home'))
        except User.DoesNotExist:
            return HttpResponse('user does not exist')

    
    return HttpResponseNotAllowed(['POST'])


def registration(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        login = request.POST.get('login')
        password = request.POST.get('password')
        r_password = request.POST.get('r_password')

        if not username or not login or not password or not r_password:
            return HttpResponse('login, username or password not found')

        if not password == r_password:
            return HttpResponse('password not equal r_password')
        
        if User.objects.filter(login=login).exists():
            return HttpResponse('user is exist')
        
        password = compress(password)
        
        user = User.objects.create(login=login, username=username, password=password)
        request.session['login'] = user.login
        request.session['username'] = user.username
        request.session['user_id'] = str(user.id)
        
        return HttpResponseRedirect(reverse_lazy('home'))
    return HttpResponseNotAllowed(['POST'])
    

def home(request):
    if not request.session.get('login'):
        return HttpResponseRedirect(redirect_to=reverse_lazy('auth_reg'))
    
    user = User.objects.get(id=request.session['user_id'])

    context = {
        'tests': Test.objects.all(),
        'user' : user,
    }

    return render(request, 'home.html', context=context)

def fq(request):    
    return render(request, 'fq.html')

def parck(request):    
    return render(request, 'parck.html')

def migr(request):    
    return render(request, 'migr.html')

def deauth(request):
    request.session.clear()
    return HttpResponseRedirect(reverse_lazy('auth_reg'))