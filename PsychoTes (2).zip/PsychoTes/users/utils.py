from hashlib import sha256

def compress(text: str = None) -> str:
    if not text:
        return None
    
    text = sha256(text.encode()).hexdigest()
    return text