from django.contrib import admin
from users.models import User
from tests.models import Question, Test, Answer, Complited

# Register your models here.
admin.site.register(User)
admin.site.register(Question)
admin.site.register(Test)
admin.site.register(Answer)
admin.site.register(Complited)
