from django.urls import path
from .views import reg_auth_page, registration, authorization, home, deauth, fq, parck, migr

urlpatterns = [
    path('', reg_auth_page, name='auth_reg'),
    path('reg_auth/', reg_auth_page, name='auth_reg'),
    path('registration/', registration, name='registration'),
    path('authorization/', authorization, name='authorization'),
    path('home/', home, name='home'),
    path('deauth/', deauth, name='deauth'),
    path('fq/', fq, name='fq'),
    path('parck/', parck, name='parck'),
    path('migr/', migr, name='migr'),
    
]
