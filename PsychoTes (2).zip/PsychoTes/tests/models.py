from django.db import models
from uuid import uuid4
from users.models import User



class Answer(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    description = models.CharField(max_length=256, verbose_name='Описание')
    correct = models.BooleanField(default=False, verbose_name='Правильный ответ')


class Question(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    title = models.CharField(max_length=256, default='default', null=True)
    answers = models.ManyToManyField(Answer)


class Test(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    title = models.CharField(max_length=64, unique=True, verbose_name='Наименование')
    questions = models.ManyToManyField(Question)

    def __str__(self):
        return self.title
    

class AnswersKit(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    question = models.ForeignKey(Question, verbose_name='Вопрос', default=None, null=True, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answer, verbose_name='Ответ', default=None, null=True, on_delete=models.CASCADE)
    user = models.ForeignKey(User, verbose_name='Пользователь', default=None, null=True, on_delete=models.CASCADE)
    test = models.ForeignKey(Test, verbose_name='Тест', default=None, null=True, on_delete=models.CASCADE)
    is_right = models.BooleanField(default=False, verbose_name='Правильность')



class Complited(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True, verbose_name='ID')
    user = models.ForeignKey(User, verbose_name='Пользователь', default=None, null=True, on_delete=models.CASCADE)
    test = models.ForeignKey(Test, verbose_name='Тест', default=None, null=True, on_delete=models.CASCADE)
    point = models.FloatField(verbose_name='Оценка', default=0.0, blank=True)

    #                                                                                    test_id | complited_id | points
    @staticmethod
    def complite_test(user_id: str, test_id: str, answers_ids: dict) -> tuple[str, str, float]:
        test = Test.objects.get(id=test_id)
        questions = test.questions.all()
        
        points = 0.0
        max_points = 5
        count_of_questions = len(questions)
        coef_per_question = max_points / count_of_questions
        failed_answers = {}
        
        # for q_id, a_id in zip(questions_ids, answers_ids):
        #     question = Question.objects.get(id=q_id)
        #     answer = question.answers.get(id=a_id)
        #     answers[question.id] = answer

        user = User.objects.get(id=user_id)

        # рассчитываем ответы по словарю answers_ids
        for question, answers in answers_ids.items():
            question = Question.objects.get(id=question)
            for answer in answers:
                answer = Answer.objects.get(id=answer)
                if answer.correct:
                    points += coef_per_question
                    answer_kit_right = AnswersKit.objects.create(test=test, user=user, question=question, answer=answer, is_right=True)
                else:
                    failed_answers[question] = answer
                    answer_kit_left = AnswersKit.objects.create(test=test, user=user, question=question, answer=answer, is_right=False)

        # сохраняем результаты
        complited_object = Complited.objects.create(user=user, point=points, test=test)

        return test_id, complited_object.id, points

        

        
        

