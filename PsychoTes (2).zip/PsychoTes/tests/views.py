from django.shortcuts import render
from .models import Question, Test, Answer, Complited, AnswersKit
from django.http import HttpResponse, HttpResponseNotAllowed, HttpResponseRedirect
from django.urls import reverse_lazy
from users.models import User


def add_test(request):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'POST':
        return HttpResponseNotAllowed(['POST'])

    title = request.POST.get('title')

    if not title:
        return HttpResponse('title not found')
    
    if Test.objects.filter(title=title).exists():
        return HttpResponse('test is exist')
    
    test = Test.objects.create(title=title)
    return HttpResponseRedirect(reverse_lazy('home'))


def add_question(request, test_id: str):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'POST':
        return HttpResponseNotAllowed(['POST'])
    
    test = Test.objects.get(id=test_id)

    question = request.POST.get('question')
    answers = (request.POST.get('answer_a'),
               request.POST.get('answer_b'),
               request.POST.get('answer_c'), 
               request.POST.get('answer_d')
               )
    correct = (
        request.POST.get('correct_a'),
        request.POST.get('correct_b'),
        request.POST.get('correct_c'), 
        request.POST.get('correct_d')
    )
    print(correct)
    
    answers = [answer for answer in answers if answer != '']
    question = Question.objects.create(title=question)

    for index, answer_ in enumerate(answers):
        created_answer = Answer.objects.create(description=answer_)
        if correct[index] in ('on', True, 1):
            print('correct')
            created_answer.correct = True
            created_answer.save()
        question.answers.add(created_answer)
    
    test.questions.add(question)
    return HttpResponseRedirect(reverse_lazy('get_test', kwargs={'test_id': test.id}))



def get_test(request, test_id: str):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'GET':
        return HttpResponseNotAllowed(['GET'])
    
    if not test_id:
        return HttpResponse('no test id')
    
    test = Test.objects.get(id=test_id)

    context = {
        'test': test,
        'questions': test.questions.all(), 
    }

    return render(request, 'test.html', context=context)    



def complite_test_view(request, test_id: str):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'GET':
        return HttpResponseNotAllowed(['GET'])
    
    
    test = Test.objects.get(id=test_id)
    user = User.objects.get(id=request.session['user_id'])

    if Complited.objects.filter(test=test, user=user).exists():
        return HttpResponseRedirect(reverse_lazy('results'))
    
    questions = test.questions.all()
    answers = {}
    for question in questions:
        answers[question.id] = question.answers.all()
    
    context = {
        'test': test,
        'questions': questions,
        'answers': answers,
    }

    return render(request, 'complite_test.html', context=context)


def results(request):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'GET':
        return HttpResponseNotAllowed(['GET'])

    user = User.objects.get(id=request.session['user_id'])
    results_ = Complited.objects.filter(user=user)
    answers_kits = {}
    rights_answers = {}

    for complited_test in results_:
        test = complited_test.test
        answers_kits[test.id] = AnswersKit.objects.filter(user=user, test=test)

    context = {
        'results': results_,
        'answers_kits': answers_kits,
    }

    return render(request, 'results.html', context=context)

def complite_test_request(request):
    if not request.session.get('login'):
        return HttpResponseRedirect(reverse_lazy('auth_reg'))
    
    if not request.method == 'POST':
        return HttpResponseNotAllowed(['POST'])
    
    test_id = request.POST.get('test_id')
    test = Test.objects.get(id=test_id)
    len_questions = len(test.questions.all())
    answer_pref = 'a_'
    question_pref = 'q_'
    questions = []
    answers = {}

    # формируем список id всех вопросов  
    for i in range(1, len_questions + 1):
        questions.append(request.POST.get(f'{question_pref}{i}'))
        question = Question.objects.get(id=questions[-1])
        len_answers = len(question.answers.all())
        for j in range(1, len_answers):
            ans = request.POST.get(f'{question_pref}{i}_{answer_pref}{j}')
            if ans:
                if not answers.get(str(question.id)):
                    answers[str(question.id)] = []
                if not ans is None: 
                    answers[str(question.id)].append(ans)

    print('QUESTIONS:', questions)

    print('ANSWERS:', answers)
    
    user = User.objects.get(id=request.session['user_id'])

    results = Complited.complite_test(user_id=user.id, test_id=test.id, answers_ids=answers)
        
    print("RESULTS:", results)
    return HttpResponseRedirect(reverse_lazy('results'))