from django.urls import path
from .views import add_test, add_question, get_test, complite_test_request, complite_test_view, results

urlpatterns = [
    path('add/', add_test, name='add_test'),
    path('add_questions/<uuid:test_id>', add_question, name='add_question'),
    path('test/<uuid:test_id>', get_test, name='get_test'),
    path('conplite_test_request', complite_test_request, name='complite_test_request'),
    path('complite_test/<uuid:test_id>', complite_test_view, name='complite_test_view'),
    path('results/', results, name='results'),
]
